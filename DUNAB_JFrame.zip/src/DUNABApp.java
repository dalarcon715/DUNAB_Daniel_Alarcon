public class DUNABApp {
    public static void main(String[] args) {
        new LoginFrame();
    }
}