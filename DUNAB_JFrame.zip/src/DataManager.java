import java.io.*;
import java.util.*;

public class DataManager {
    private static final String FILE = "dunabs.txt";

    public static void guardarDUNAB(DUNAB d) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE, true))) {
            bw.write(d.getHora() + ";" + d.getNombreEvento() + ";" + d.isAsistencia());
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<DUNAB> cargarDUNABs() {
        List<DUNAB> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(";");
                lista.add(new DUNAB(p[1], p[0], Boolean.parseBoolean(p[2])));
            }
        } catch (IOException e) {
            System.out.println("No se encontraron eventos guardados.");
        }
        return lista;
    }
}