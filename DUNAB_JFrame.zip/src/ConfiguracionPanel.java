import javax.swing.*;
import java.awt.*;

public class ConfiguracionPanel extends JPanel {
    public ConfiguracionPanel() {
        setLayout(new GridLayout(5, 1, 10, 10));
        setBackground(Color.WHITE);

        JTextField txtNombre = new JTextField();
        txtNombre.setBorder(BorderFactory.createTitledBorder("Nombre del estudiante"));

        JTextField txtCarrera = new JTextField();
        txtCarrera.setBorder(BorderFactory.createTitledBorder("Carrera"));

        JTextField txtSemestre = new JTextField();
        txtSemestre.setBorder(BorderFactory.createTitledBorder("Semestre"));

        JButton btnGuardar = new JButton("Guardar cambios");
        btnGuardar.setBackground(new Color(50,205,50));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.addActionListener(e -> JOptionPane.showMessageDialog(this, "Configuración guardada."));

        add(txtNombre);
        add(txtCarrera);
        add(txtSemestre);
        add(btnGuardar);
    }
}