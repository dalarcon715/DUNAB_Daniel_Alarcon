import javax.swing.*;
import java.awt.*;

public class DashboardFrame extends JFrame {
    private JPanel mainPanel;

    public DashboardFrame() {
        setTitle("DUNAB - Panel Principal");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel sideMenu = new JPanel();
        sideMenu.setLayout(new GridLayout(4, 1, 10, 10));
        sideMenu.setBackground(new Color(245,245,245));
        sideMenu.setPreferredSize(new Dimension(150, 0));

        JButton btnInicio = new JButton("Inicio");
        JButton btnFormulario = new JButton("Formulario");
        JButton btnCalendario = new JButton("Calendario");
        JButton btnConfig = new JButton("Configuración");

        btnInicio.addActionListener(e -> setPanel(new InicioPanel()));
        btnFormulario.addActionListener(e -> setPanel(new FormularioPanel()));
        btnCalendario.addActionListener(e -> setPanel(new CalendarioPanel()));
        btnConfig.addActionListener(e -> setPanel(new ConfiguracionPanel()));

        sideMenu.add(btnInicio);
        sideMenu.add(btnFormulario);
        sideMenu.add(btnCalendario);
        sideMenu.add(btnConfig);

        mainPanel = new JPanel(new BorderLayout());
        setPanel(new InicioPanel());

        add(sideMenu, BorderLayout.WEST);
        add(mainPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private void setPanel(JPanel panel) {
        mainPanel.removeAll();
        mainPanel.add(panel, BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }
}