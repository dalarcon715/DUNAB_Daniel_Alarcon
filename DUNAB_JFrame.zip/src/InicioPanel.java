import javax.swing.*;
import java.awt.*;

public class InicioPanel extends JPanel {
    public InicioPanel() {
        setLayout(new GridLayout(4, 1, 10, 10));
        setBackground(Color.WHITE);

        JLabel foto = new JLabel("Foto Estudiante", JLabel.CENTER);
        JLabel nombre = new JLabel("Pedro Pérez", JLabel.CENTER);
        nombre.setFont(new Font("Poppins", Font.BOLD, 18));

        int total = DataManager.cargarDUNABs().size() * 10;
        JLabel lblDunabs = new JLabel("Tienes " + total + " DUNABs", JLabel.CENTER);
        lblDunabs.setFont(new Font("Poppins", Font.PLAIN, 16));

        JLabel faltan = new JLabel("Te faltan " + (80 - total) + " DUNABs", JLabel.CENTER);
        faltan.setForeground(new Color(255,140,0));

        add(foto);
        add(nombre);
        add(lblDunabs);
        add(faltan);
    }
}