import javax.swing.*;
import java.awt.*;

public class CalendarioPanel extends JPanel {
    public CalendarioPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Calendario de eventos UNAB", JLabel.CENTER);
        titulo.setFont(new Font("Poppins", Font.BOLD, 16));

        DefaultListModel<String> modelo = new DefaultListModel<>();
        for (DUNAB d : DataManager.cargarDUNABs()) {
            modelo.addElement(d.getHora() + " - " + d.getNombreEvento());
        }

        JList<String> lista = new JList<>(modelo);
        add(titulo, BorderLayout.NORTH);
        add(new JScrollPane(lista), BorderLayout.CENTER);
    }
}