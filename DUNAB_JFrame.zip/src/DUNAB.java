public class DUNAB {
    private String nombreEvento;
    private String hora;
    private boolean asistencia;

    public DUNAB(String nombreEvento, String hora, boolean asistencia) {
        this.nombreEvento = nombreEvento;
        this.hora = hora;
        this.asistencia = asistencia;
    }

    public String getNombreEvento() { return nombreEvento; }
    public String getHora() { return hora; }
    public boolean isAsistencia() { return asistencia; }
}