import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;

public class FormularioPanel extends JPanel {
    private JTable tabla;

    public FormularioPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Eventos inscritos", JLabel.CENTER);
        titulo.setFont(new Font("Poppins", Font.BOLD, 16));

        String[] columnas = {"Hora", "Evento", "Acción"};
        java.util.List<DUNAB> eventos = DataManager.cargarDUNABs();

        Object[][] datos = new Object[eventos.size()][3];
        for (int i = 0; i < eventos.size(); i++) {
            DUNAB d = eventos.get(i);
            datos[i][0] = d.getHora();
            datos[i][1] = d.getNombreEvento();
            datos[i][2] = "Dar de baja";
        }

        DefaultTableModel modelo = new DefaultTableModel(datos, columnas);
        tabla = new JTable(modelo);

        add(titulo, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }
}