import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtClave;

    public LoginFrame() {
        setTitle("DUNAB - Iniciar sesión");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5,1));

        JLabel lblLogo = new JLabel("Facultad de Ingeniería UNAB", JLabel.CENTER);
        lblLogo.setFont(new Font("Poppins", Font.BOLD, 18));
        lblLogo.setForeground(new Color(50,205,50));

        txtUsuario = new JTextField();
        txtUsuario.setBorder(BorderFactory.createTitledBorder("Usuario"));
        txtClave = new JPasswordField();
        txtClave.setBorder(BorderFactory.createTitledBorder("Contraseña"));

        JButton btnLogin = new JButton("Iniciar sesión");
        btnLogin.setBackground(new Color(50,205,50));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.addActionListener(e -> {
            new DashboardFrame();
            dispose();
        });

        add(lblLogo);
        add(txtUsuario);
        add(txtClave);
        add(btnLogin);
        add(new JLabel("¿Olvidaste tu contraseña?", JLabel.CENTER));

        setVisible(true);
    }
}